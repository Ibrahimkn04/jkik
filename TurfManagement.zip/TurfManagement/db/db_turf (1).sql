-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 03, 2020 at 09:55 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_turf`
--
CREATE DATABASE IF NOT EXISTS `db_turf` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_turf`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_allocation`
--

CREATE TABLE IF NOT EXISTS `tbl_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `managerid` int(11) NOT NULL,
  `turfid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_allocation`
--

INSERT INTO `tbl_allocation` (`id`, `managerid`, `turfid`) VALUES
(1, 1, 1),
(2, 2, 3),
(3, 3, 4),
(4, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE IF NOT EXISTS `tbl_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(50) NOT NULL,
  `turfid` int(50) NOT NULL,
  `tdays` varchar(50) NOT NULL,
  `bdate` date NOT NULL,
  `rdate` date NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`id`, `userid`, `turfid`, `tdays`, `bdate`, `rdate`, `status`) VALUES
(1, 1, 1, '3', '2020-10-26', '0000-00-00', 'confirmed'),
(2, 2, 3, '8', '2020-10-27', '0000-00-00', 'confirmed'),
(3, 3, 4, '3', '2020-11-07', '0000-00-00', 'confirmed'),
(4, 4, 3, '4', '2003-11-20', '2020-11-18', 'booked'),
(5, 5, 5, '4', '2003-11-20', '2020-11-20', 'confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `email`, `password`, `usertype`) VALUES
(1, 'admin@gmail.com', 'admin', 'admin'),
(2, 'jeena@gmail.com', 'jeena@123', 'user'),
(3, 'abhi@gmail.com', 'abhi', 'Manager'),
(4, 'shilpa@gmail.com', 'shilpa', 'Manager'),
(5, 'shyam@gmail.com', 'shyam@123', 'user'),
(6, 'jithin@gmail.com', 'jithin@123', 'Manager'),
(7, 'athul@gmail.com', 'thul@1234', 'user'),
(8, 'akshay@gmail.com', 'akshay@1234', 'Manager'),
(9, 'riya@gmail.com', 'riya@123', 'user'),
(10, 'jiya@gmail.com', 'jiya@1234', 'Manager'),
(11, 'hus@gmail.com', 'hus@123', 'user'),
(12, 'pra@gmail.com', 'pra@123', 'Manager'),
(13, 'aa@gmail.com', 'aa@123', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manager`
--

CREATE TABLE IF NOT EXISTS `tbl_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_manager`
--

INSERT INTO `tbl_manager` (`id`, `name`, `address`, `place`, `phone`, `email`, `status`) VALUES
(1, 'shilpa', 'nnjk', 'pta', '7458963210', 'shilpa@gmail.com', '1'),
(2, 'jithin', 'edappilly', 'thrissur', '7876777777', 'jithin@gmail.com', '1'),
(3, 'Akshay', 'nj', 'hb', '9652320252', 'akshay@gmail.com', '1'),
(4, 'jiya', 'hbjn', 'nm', '8569655555', 'jiya@gmail.com', '1'),
(5, 'prashob', 'vb', 'bn', '6666666666', 'pra@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(50) NOT NULL,
  `bid` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `cnumber` varchar(50) NOT NULL,
  `amnt` varchar(50) NOT NULL,
  `cvv` varchar(50) NOT NULL,
  `exp` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `pdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `userid`, `bid`, `cname`, `cnumber`, `amnt`, `cvv`, `exp`, `status`, `pdate`) VALUES
(1, 1, 1, 'Jeena ', '8888 8888 8888 8888', '5000', '222', '12 / 25', 'paid', '2020-10-27'),
(2, 2, 2, 'Jithin', '7777 7777 7777 7777', '5000', '222', '12 / 28', 'paid', '2020-10-27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reg`
--

CREATE TABLE IF NOT EXISTS `tbl_reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `age` int(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_reg`
--

INSERT INTO `tbl_reg` (`id`, `name`, `address`, `place`, `age`, `contact`, `email`, `status`) VALUES
(1, 'jeena', 'edappilly', 'edappilly', 29, '9999999999', 'jeena@gmail.com', '1'),
(2, 'Shyam', 'edappilly', 'idukki', 26, '9898789899', 'shyam@gmail.com', '1'),
(3, 'Athul', 'vgbhn', 'ekm', 21, '9874562032', 'athul@gmail.com', '1'),
(4, 'riya', 'gvbhnj', 'vgbhnjk', 21, '3258520325', 'riya@gmail.com', '1'),
(5, 'hussain', 'gvbhnj', 'gbhnj', 22, '9865235852', 'hus@gmail.com', '1'),
(6, 'aa', 'gbh', 'vb', 0, '4525555555', 'aa@gmail.com', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_turf`
--

CREATE TABLE IF NOT EXISTS `tbl_turf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `turfname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `maxpeople` varchar(50) NOT NULL,
  `itemimage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_turf`
--

INSERT INTO `tbl_turf` (`id`, `turfname`, `location`, `maxpeople`, `itemimage`) VALUES
(1, 'turff1', 'Ernakulam', '12', 'images/'),
(2, 'Turf2', 'Thrissur', '12', 'images/'),
(3, 'JNK', 'kochi', '30', 'images/'),
(4, 'turfnew', 'ernakulam', '23', 'images/plant-houseplant-indoor-pot-wallpaper.jpg'),
(5, 'turfnew1', 'aluva', '21', 'images/plant-houseplant-indoor-pot-wallpaper.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
