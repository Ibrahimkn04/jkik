<?php
include 'managerbase.php';
?>